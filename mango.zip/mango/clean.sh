tmux kill-server
rm -rf worktree*
rm -rf ~/.mango
