tmux kill-server
rm -rf worktree*
rm -rf ~/.mango
git worktree prune
